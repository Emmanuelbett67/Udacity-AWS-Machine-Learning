from setuptools import setup

setup(name='gb_distr_class',
      version='0.1.1',
      description='Gaussian and Binomial distributions',
      packages=['gb_distr_class'],
      author=['Stefania Marcotti'],
      zip_safe=False)
